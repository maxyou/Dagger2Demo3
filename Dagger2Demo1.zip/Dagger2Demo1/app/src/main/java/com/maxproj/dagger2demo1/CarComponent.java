package com.maxproj.dagger2demo1;


import dagger.Component;

@Component
public interface CarComponent {
    void inject(Car car);
}
