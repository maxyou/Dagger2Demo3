package com.maxproj.dagger2demo2;

import javax.inject.Inject;

/**
 * Created by youhy on 17/7/27.
 */

public class Engine {
    @Inject
    Engine(){}
    public String run(){
        return "Engine is running!";
    }

}
